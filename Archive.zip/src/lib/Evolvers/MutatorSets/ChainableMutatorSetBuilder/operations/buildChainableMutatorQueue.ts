import { MutableData, Mutator, SortaPromise } from "@Evolvers/Types";
import log from "@Shared/Log/log";
import { Mutable } from "@Shared/String/makeMutable";

const logger = log("Queue");

interface Params<TEvolverData, TParamName extends Mutable<string>> {
    argName: TParamName;
    setMutableData: (data: MutableData<TEvolverData, TParamName>) => void;
    getMutableData: () => MutableData<TEvolverData, TParamName>;
}

export const buildChainableMutatorQueue = <TEvolverData, TParamName extends Mutable<string>>({
    argName,
    getMutableData,
    setMutableData,
}: Params<TEvolverData, TParamName>) => {
    let isAsyncEncountered = false;
    let queue: Promise<any> = Promise.resolve();

    const buildQueueOperation = (
        selfPath: string,
        mutator: Mutator<TEvolverData, TParamName, SortaPromise<TEvolverData>>,
        args: any[],
    ) => {
        return () => {
            const mutableData = getMutableData();
            const mutatorResult = mutator(mutableData, ...args);

            if (mutatorResult === undefined) {
                logger.error(
                    `${selfPath} returned undefined. This is likely an error occuring inside the mutator.`,
                );
            }

            if (mutatorResult instanceof Promise) {
                // Async operation encountered, switch to queuing mode
                isAsyncEncountered = true;
                return mutatorResult.then((result) => {
                    logger.debug(`{ASYNC} ${selfPath} = `, result);
                    setMutableData(inputToObject(result)); // Assuming funcResult updates mutableData
                    return result;
                });
            } else {
                logger.debug(`{SYNC} ${selfPath} = `, mutatorResult);
                setMutableData(inputToObject(mutatorResult)); // Assuming funcResult updates mutableData
                return mutatorResult;
            }
        };
    };

    const inputToObject = (input: TEvolverData): { [key in TParamName]: TEvolverData } => {
        return { [argName]: input } as {
            [key in TParamName]: TEvolverData;
        };
    };

    const queueMutation = (
        mutatorPath: string,
        func: Mutator<TEvolverData, TParamName, SortaPromise<TEvolverData>>,
        args: any[],
    ) => {
        logger.debug(`${mutatorPath}(${args}) queued`);

        const operation = buildQueueOperation(mutatorPath, func, args);

        if (isAsyncEncountered) {
            // Queue all operations after the first async is encountered
            queue = queue.then(operation);
        } else {
            const result = operation();
            if (result instanceof Promise) {
                queue = result;
            }

            return result;
        }

        return queue;
    };

    return queueMutation;
};
